#!/usr/bin/env python
""" Module to give informations on the ASes seen per DNS in the database
"""

import sqlite3
from re import match
#from collections import defaultdict

DNS_RESOLVERS = ('open', 'google', 'default')

# TODO: take new prefixes
IP_MAP = [('google_as', ['209.85.142.0/23',
                         '209.85.146.0/24',
                         '209.85.147.0/24',
                         '209.85.226.0/23',
                         '209.85.228.0/23',
                         '74.125.230.0/24',
                         '74.125.76.0/23']),
          ('youtube_as', ['74.125.126.0/23',
                          '74.125.46.0/23',
                          '74.125.94.0/23'])]

def as_ip_min_max(prefix):
    """Return a tuple with the min and max value of IP (converted to int) on
    the AS
    >>> as_ip_min_max('0.0.0.1/32')
    (1, 1)
    >>> as_ip_min_max('0.0.0.1/0')
    (0, 4294967295)
    >>> as_ip_min_max('209.85.147.0/24')
    (3512046336, 3512046591)
    >>> as_ip_min_max('209.85.147.11/24')
    (3512046336, 3512046591)
    >>> as_ip_min_max('209.85.147.0/23')
    (3512046080, 3512046591)
    >>> as_ip_min_max('209.85.147.155/23')
    (3512046080, 3512046591)
    """
    match_prefix = match("(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/(\d{1,2})",
                         prefix)
    if not match_prefix:
        return None
    ip_addr, prefix = match_prefix.groups()
    prefix = int(prefix)
    bin_prefix = '0b' + ('1' * prefix) + ('0' * (32 - prefix))
    int_prefix = int(bin_prefix, 2)
    ip_addr = ip2int(ip_addr)
    min_ip = ip_addr & int_prefix
    if prefix == 32:
        max_ip = ip_addr
    else:
        max_ip = min_ip + int('0b' + '1' * (32 - prefix), 2)
    return min_ip, max_ip

def ip2int(ip_addr):
    """Return the int value of IP address
    >>> ip2int('0.0.0.1')
    1
    >>> ip2int('0.0.1.0')
    256
    >>> ip2int('0.0.1.1')
    257
    >>> ip2int('255.255.255.255')
    4294967295
    """
    ret = 0
    match_ip = match("(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})", ip_addr)
    if not match_ip:
        return 0
    for i in xrange(4):
        int_group = int(match_ip.groups()[i])
        assert int_group < 256, "Incorrect IP address"
        ret = (ret << 8) + int_group
    return ret

def as_data(db_file=None):
    """Function to plot the data in the database. Creates sub plots for
     the column names.
    """
    if not db_file:
        from . import config_pytomo
        db_file = config_pytomo.DATABASE_TIMESTAMP
    conn = sqlite3.connect(str(db_file),
                           detect_types=sqlite3.PARSE_DECLTYPES)
    cur = conn.cursor()
    user_table = cur.execute('select name from sqlite_master '
                             'where type = "table"').fetchall()[0][0]
    data = dict()
    #find the number of resolvers used.
    for resolver in DNS_RESOLVERS:
        cmd = ' '.join(('select IP from', user_table,
                        'where Resolver LIKE %%%s%%;' % resolver))
        cur.execute(cmd)
        ips = cur.fetchall()
        # use groupby
        data[resolver] = map(ip2int, ips)
    return data

if __name__ == '__main__':
    import doctest
    doctest.testmod()

